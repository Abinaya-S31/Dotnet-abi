﻿using System;
using System.Threading.Tasks;
using RetailStockTracker.Models;

using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RetailStockTracker.Models;

namespace RetailStockTracker
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using var context = new AppDbContext();

            Console.WriteLine("🔍 All Products:");
            var products = await context.Products.ToListAsync();
            foreach (var p in products)
                Console.WriteLine($"{p.Name} - ₹{p.Price}");

            Console.WriteLine("\n🔎 Find by ID (ID = 1):");
            var product = await context.Products.FindAsync(1);
            Console.WriteLine($"Found: {product?.Name ?? "Not found"}");

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailInventory.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int StockLevel { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}

